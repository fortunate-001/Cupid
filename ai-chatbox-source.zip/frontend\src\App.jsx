import { Routes, Route } from "react-router-dom";

import Chat from "./pages/Chat";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import ResetPassword from "./pages/ResetPassword";

import { ChatProvider } from "./context/ChatContext";

export default function App() {
  return (
    <ChatProvider>

      <Routes>

        <Route path="/" element={<Chat />} />
        <Route path="/chat" element={<Chat />} />

        <Route path="/login" element={<Login />} />

        <Route path="/register" element={<Register />} />

        <Route
          path="/forgot-password"
          element={<ForgotPassword />}
        />

        <Route
          path="/reset-password"
          element={<ResetPassword />}
        />

      </Routes>

    </ChatProvider>
  );
}