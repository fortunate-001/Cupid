import { IoClose } from "react-icons/io5";

export default function SettingsModal({

    open,

    onClose,

    children,

}){

    if(!open) return null;

    return(

        <div
            className="settings-overlay"
            onClick={onClose}
        >

            <div
                className="settings-modal"
                onClick={(e)=>e.stopPropagation()}
            >

                <div className="settings-header">

                    <h2>

                        Settings

                    </h2>

                    <button
                        onClick={onClose}
                    >

                        <IoClose/>

                    </button>

                </div>

                {children}

            </div>

        </div>

    );

}