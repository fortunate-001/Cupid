import { useState } from "react";

import {
  FiMenu,
  FiPlus,
  FiSearch,
  FiSettings,
  FiMessageSquare,
  FiInbox,
  FiImage,
  FiFolder,
  FiGrid,
  FiX,
  FiTrash2,
} from "react-icons/fi";

import { useChat } from "../../context/ChatContext";

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);

  const [activePanel, setActivePanel] = useState(null);

  const [search, setSearch] = useState("");

  const {
    conversations = [],
    createNewChat,
    selectConversation,
    clearConversations,
  } = useChat();

  // ============================
  // SEARCH
  // ============================

  const filteredConversations =
    conversations.filter((chat) =>
      chat.title
        ?.toLowerCase()
        .includes(search.toLowerCase())
    );

  // ============================
  // NEW CHAT
  // ============================

  const handleNewChat = () => {
    createNewChat();
    setActivePanel(null);
  };

  // ============================
  // CLEAR HISTORY
  // ============================

  const handleClearHistory = async () => {
    const confirmed = window.confirm(
      "Are you sure you want to clear all your chat history?"
    );

    if (!confirmed) return;

    await clearConversations();
  };

  // ============================
  // SIDEBAR TOOL
  // ============================

  const openPanel = (panel) => {
    setActivePanel(
      activePanel === panel ? null : panel
    );
  };

  return (
    <>
      <aside
        className={
          collapsed
            ? "sidebar collapsed"
            : "sidebar"
        }
      >

        {/* ========================= */}
        {/* TOP */}
        {/* ========================= */}

        <div className="sidebar-top">

          <button
            className="icon-btn"
            onClick={() =>
              setCollapsed(!collapsed)
            }
            title="Toggle sidebar"
          >
            <FiMenu />
          </button>

        </div>

        {/* ========================= */}
        {/* NEW CHAT */}
        {/* ========================= */}

        <button
          className="new-chat-btn"
          onClick={handleNewChat}
        >
          <FiPlus />

          {!collapsed && (
            <span>New Chat</span>
          )}
        </button>

        {/* ========================= */}
        {/* SEARCH */}
        {/* ========================= */}

        {!collapsed && (
          <div className="sidebar-search">

            <FiSearch />

            <input
              type="text"
              placeholder="Search chats..."
              value={search}
              onChange={(e) =>
                setSearch(e.target.value)
              }
            />

            {search && (
              <button
                onClick={() => setSearch("")}
              >
                <FiX />
              </button>
            )}

          </div>
        )}

        {/* ========================= */}
        {/* TOOLS */}
        {/* ========================= */}

        {!collapsed && (
          <div className="sidebar-tools">

            <button
              className={
                activePanel === "images"
                  ? "sidebar-btn active"
                  : "sidebar-btn"
              }
              onClick={() =>
                openPanel("images")
              }
            >
              <FiImage />
              <span>Images</span>
            </button>

            <button
              className={
                activePanel === "library"
                  ? "sidebar-btn active"
                  : "sidebar-btn"
              }
              onClick={() =>
                openPanel("library")
              }
            >
              <FiFolder />
              <span>Library</span>
            </button>

            <button
              className={
                activePanel === "projects"
                  ? "sidebar-btn active"
                  : "sidebar-btn"
              }
              onClick={() =>
                openPanel("projects")
              }
            >
              <FiGrid />
              <span>Projects</span>
            </button>

          </div>
        )}

        {/* ========================= */}
        {/* RECENT */}
        {/* ========================= */}

        {!collapsed && (
          <div className="history-section">

            <div className="history-header">

              <span>Recent</span>

              {conversations.length > 0 && (
                <button
                  className="clear-history-btn"
                  onClick={
                    handleClearHistory
                  }
                  title="Clear history"
                >
                  Clear
                </button>
              )}

            </div>

            <div className="chat-history">

              {filteredConversations.length ===
              0 ? (

                <div className="empty-state">

                  <FiInbox />

                  <p>
                    {search
                      ? "No chats found"
                      : "No conversations yet"}
                  </p>

                </div>

              ) : (

                filteredConversations.map(
                  (chat) => (

                    <button
                      key={chat.sessionId}
                      className="chat-item"
                      onClick={() =>
                        selectConversation(
                          chat.sessionId
                        )
                      }
                    >

                      <FiMessageSquare />

                      <span>
                        {chat.title}
                      </span>

                    </button>

                  )
                )

              )}

            </div>

          </div>
        )}

        {/* ========================= */}
        {/* FOOTER */}
        {/* ========================= */}

        <div className="sidebar-footer">

          {!collapsed && (
            <button
              className="sidebar-btn"
              onClick={() =>
                openPanel("settings")
              }
            >
              <FiSettings />

              <span>
                Settings
              </span>
            </button>
          )}

        </div>

      </aside>

      {/* ========================= */}
      {/* SIDE PANELS */}
      {/* ========================= */}

      {activePanel && (
        <div className="sidebar-panel">

          <div className="sidebar-panel-header">

            <h2>
              {activePanel === "images" &&
                "Images"}

              {activePanel === "library" &&
                "Library"}

              {activePanel === "projects" &&
                "Projects"}

              {activePanel === "settings" &&
                "Settings"}
            </h2>

            <button
              onClick={() =>
                setActivePanel(null)
              }
            >
              <FiX />
            </button>

          </div>

          {/* IMAGES */}

          {activePanel === "images" && (
            <div className="panel-empty">

              <FiImage />

              <h3>
                Your images
              </h3>

              <p>
                Images generated by Cupid
                will appear here.
              </p>

            </div>
          )}

          {/* LIBRARY */}

          {activePanel === "library" && (
            <div className="panel-empty">

              <FiFolder />

              <h3>
                Your Library
              </h3>

              <p>
                Uploaded files and documents
                will appear here.
              </p>

            </div>
          )}

          {/* PROJECTS */}

          {activePanel === "projects" && (
            <div className="panel-empty">

              <FiGrid />

              <h3>
                Projects
              </h3>

              <p>
                Create and organize your
                Cupid projects here.
              </p>

              <button className="panel-action">
                <FiPlus />
                Create Project
              </button>

            </div>
          )}

          {/* SETTINGS */}

          {activePanel === "settings" && (
            <div className="settings-panel">

              <button>
                General
              </button>

              <button>
                Appearance
              </button>

              <button>
                Profile
              </button>

              <button>
                Memory
              </button>

              <button>
                Account
              </button>

            </div>
          )}

        </div>
      )}
    </>
  );
}