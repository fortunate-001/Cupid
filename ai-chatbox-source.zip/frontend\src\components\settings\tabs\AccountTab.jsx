import { useAuth } from "../../../context/AuthContext";

export default function AccountTab(){

    const {logout}=useAuth();

    return(

        <>

            <h2>

                Account

            </h2>

            <button
                className="logout-btn"
                onClick={logout}
            >

                Logout

            </button>

        </>

    );

}