import { useEffect, useRef, useState } from "react";

import Sidebar from "../components/layout/Sidebar";
import Header from "../components/layout/Header";

import MessageBubble from "../components/chat/MessageBubble";
import MessageInput from "../components/chat/MessageInput";
import Typing from "../components/chat/Typing";

import AuthModal from "../components/auth/AuthModal";

import { useAuth } from "../context/AuthContext";
import { useChat } from "../context/ChatContext";

export default function Chat() {

  const {
    messages,
    loading,
  } = useChat();

  const {
    user,
    loading: authLoading,
    continueAsGuest,
  } = useAuth();

  const bottomRef = useRef(null);

  const [showAuth, setShowAuth] = useState(false);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({
      behavior: "smooth",
    });
  }, [messages, loading]);

  useEffect(() => {

    if (authLoading) return;

    const guest =
      sessionStorage.getItem("guest_mode");

    if (user || guest) {
      setShowAuth(false);
    } else {
      setShowAuth(true);
    }

  }, [user, authLoading]);

  return (
    <div className="chat-page">

      <Sidebar />

      <main className="chat-main">

        <Header />

        <div className="messages">

    {messages.length === 0 ? (

        <div className="welcome">

            <h1>

                Hey there!

            </h1>

            <p>

                How can I help you today?

            </p>

        </div>

          ) : (

              messages.map((message)=>(

                  <MessageBubble
                      key={message.id}
                      sender={message.sender}
                      text={message.text}
                      isImage={message.isImage}
                      imageUrl={message.imageUrl}
                  />

              ))

          )}

          {loading && <Typing />}

          <div ref={bottomRef}></div>

      </div>

      <div className="input-wrapper">

          {/* <MessageInput
              disabled={showAuth}
          /> */}

      </div>

        <MessageInput
          disabled={showAuth}
        />

      </main>

      {showAuth && (
        <AuthModal
          onGuest={() => {

            continueAsGuest();

            setShowAuth(false);

          }}
        />
      )}

    </div>
  );
}