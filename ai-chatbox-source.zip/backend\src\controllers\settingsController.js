// src/controllers/settingsController.js

import connectDB from "../../lib/mongodb.js";
import User from "../models/User.js";

// =========================================
// GET SETTINGS
// =========================================

export const getSettings = async (
  req,
  res
) => {
  try {
    await connectDB();

    const user = req.user;

    if (!user) {
      return res.status(401).json({
        error:
          "Authentication required",
      });
    }

    const freshUser =
      await User.findById(user._id).lean();

    if (!freshUser) {
      return res.status(404).json({
        error: "User not found",
      });
    }

    return res.json({
      settings: {
        name: freshUser.name,
        email: freshUser.email,
        avatar: freshUser.avatar || "",

        aiSettings: {
          personality:
            freshUser.aiSettings
              ?.personality ||
            "friendly",

          responseStyle:
            freshUser.aiSettings
              ?.responseStyle ||
            "normal",

          language:
            freshUser.aiSettings
              ?.language ||
            "English",

          rememberConversations:
            freshUser.aiSettings
              ?.rememberConversations ??
            true,

          voiceGender:
            freshUser.aiSettings
              ?.voiceGender ||
            "female",

          voiceEnabled:
            freshUser.aiSettings
              ?.voiceEnabled ??
            true,
        },

        subscription: {
          tier:
            freshUser.subscription
              ?.tier ||
            "free",

          status:
            freshUser.subscription
              ?.status ||
            "active",
        },
      },
    });
  } catch (error) {
    console.error(
      "❌ Get settings error:",
      error
    );

    return res.status(500).json({
      error:
        "Failed to load settings.",
    });
  }
};

// =========================================
// UPDATE AI SETTINGS
// =========================================

export const updateSettings = async (
  req,
  res
) => {
  try {
    await connectDB();

    const user = req.user;

    if (!user) {
      return res.status(401).json({
        error:
          "Authentication required",
      });
    }

    const {
      personality,
      responseStyle,
      language,
      rememberConversations,
      voiceGender,
      voiceEnabled,
    } = req.body;

    const update = {};

    // -----------------------------------------
    // PERSONALITY
    // -----------------------------------------

    if (personality !== undefined) {
      const allowed = [
        "friendly",
        "professional",
        "casual",
        "creative",
      ];

      if (!allowed.includes(personality)) {
        return res.status(400).json({
          error:
            "Invalid personality.",
        });
      }

      update[
        "aiSettings.personality"
      ] = personality;
    }

    // -----------------------------------------
    // RESPONSE STYLE
    // -----------------------------------------

    if (responseStyle !== undefined) {
      const allowed = [
        "short",
        "normal",
        "detailed",
      ];

      if (
        !allowed.includes(responseStyle)
      ) {
        return res.status(400).json({
          error:
            "Invalid response style.",
        });
      }

      update[
        "aiSettings.responseStyle"
      ] = responseStyle;
    }

    // -----------------------------------------
    // LANGUAGE
    // -----------------------------------------

    if (language !== undefined) {
      update[
        "aiSettings.language"
      ] = language;
    }

    // -----------------------------------------
    // MEMORY
    // -----------------------------------------

    if (
      rememberConversations !==
      undefined
    ) {
      update[
        "aiSettings.rememberConversations"
      ] = Boolean(
        rememberConversations
      );
    }

    // -----------------------------------------
    // VOICE GENDER
    // -----------------------------------------

    if (voiceGender !== undefined) {
      const allowed = [
        "female",
        "male",
      ];

      if (!allowed.includes(voiceGender)) {
        return res.status(400).json({
          error:
            "Voice must be either male or female.",
        });
      }

      update[
        "aiSettings.voiceGender"
      ] = voiceGender;
    }

    // -----------------------------------------
    // VOICE ENABLED
    // -----------------------------------------

    if (voiceEnabled !== undefined) {
      update[
        "aiSettings.voiceEnabled"
      ] = Boolean(voiceEnabled);
    }

    const updatedUser =
      await User.findByIdAndUpdate(
        user._id,
        {
          $set: update,
        },
        {
          new: true,
          runValidators: true,
        }
      ).lean();

    if (!updatedUser) {
      return res.status(404).json({
        error: "User not found",
      });
    }

    return res.json({
      success: true,

      settings: {
        name: updatedUser.name,
        email: updatedUser.email,
        avatar:
          updatedUser.avatar || "",

        aiSettings: {
          personality:
            updatedUser.aiSettings
              ?.personality ||
            "friendly",

          responseStyle:
            updatedUser.aiSettings
              ?.responseStyle ||
            "normal",

          language:
            updatedUser.aiSettings
              ?.language ||
            "English",

          rememberConversations:
            updatedUser.aiSettings
              ?.rememberConversations ??
            true,

          voiceGender:
            updatedUser.aiSettings
              ?.voiceGender ||
            "female",

          voiceEnabled:
            updatedUser.aiSettings
              ?.voiceEnabled ??
            true,
        },

        subscription: {
          tier:
            updatedUser.subscription
              ?.tier ||
            "free",

          status:
            updatedUser.subscription
              ?.status ||
            "active",
        },
      },
    });
  } catch (error) {
    console.error(
      "❌ Update settings error:",
      error
    );

    return res.status(500).json({
      error:
        "Failed to update settings.",
    });
  }
};

// =========================================
// UPDATE PROFILE
// =========================================

export const updateProfile = async (
  req,
  res
) => {
  try {
    await connectDB();

    const user = req.user;

    if (!user) {
      return res.status(401).json({
        error:
          "Authentication required",
      });
    }

    const {
      name,
      avatar,
    } = req.body;

    const update = {};

    if (
      name !== undefined
    ) {
      if (!name.trim()) {
        return res.status(400).json({
          error:
            "Name cannot be empty.",
        });
      }

      update.name =
        name.trim();
    }

    if (
      avatar !== undefined
    ) {
      update.avatar =
        avatar;
    }

    const updatedUser =
      await User.findByIdAndUpdate(
        user._id,
        {
          $set: update,
        },
        {
          new: true,
          runValidators: true,
        }
      ).lean();

    return res.json({
      success: true,

      user: {
        name:
          updatedUser.name,

        email:
          updatedUser.email,

        avatar:
          updatedUser.avatar ||
          "",
      },
    });
  } catch (error) {
    console.error(
      "❌ Update profile error:",
      error
    );

    return res.status(500).json({
      error:
        "Failed to update profile.",
    });
  }
};

export default {
  getSettings,
  updateSettings,
  updateProfile,
};