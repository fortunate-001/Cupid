import { createContext, useContext, useEffect, useState } from "react";

import * as authService from "../services/auth";

const AuthContext = createContext();

export function AuthProvider({ children }) {

  const [user, setUser] = useState(null);

  const [loading, setLoading] = useState(true);

  const [isGuest, setIsGuest] = useState(false);

  useEffect(() => {

    async function loadUser() {

      try {

        const token = localStorage.getItem("token");

        if (!token) {

          setLoading(false);

          return;

        }

        const data =
          await authService.getCurrentUser();

        setUser(data.user);

      } catch {

        localStorage.removeItem("token");

        setUser(null);

      } finally {

        setLoading(false);

      }

    }

    loadUser();

  }, []);

  const login = async (credentials) => {

    const data =
      await authService.login(credentials);

    setUser(data.user);

    setIsGuest(false);

    return data;

  };

  const register = async (userData) => {

    const data =
      await authService.register(userData);

    setUser(data.user);

    setIsGuest(false);

    return data;

  };

  const continueAsGuest = () => {

    setIsGuest(true);

    sessionStorage.setItem(
      "guest_mode",
      "true"
    );

  };

  const logout = () => {

    authService.logout();

    sessionStorage.removeItem(
      "guest_mode"
    );

    setUser(null);

    setIsGuest(false);

  };

  return (

    <AuthContext.Provider
      value={{
        user,
        loading,
        isGuest,
        login,
        register,
        logout,
        continueAsGuest,
      }}
    >

      {children}

    </AuthContext.Provider>

  );

}

export const useAuth = () => useContext(AuthContext);