export default function MemoryTab(){

    return(

        <>

            <h2>

                Memory

            </h2>

            <p>

                Manage what Cupid remembers.

            </p>

        </>

    );

}