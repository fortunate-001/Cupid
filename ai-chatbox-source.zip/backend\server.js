// server.js
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import connectDB from './lib/mongodb.js';
import authRoutes from './src/routes/authRoutes.js';
import chatRoutes from './src/routes/chatRoutes.js';
import subscriptionRoutes from './src/routes/subscriptionRoutes.js';
import { errorHandler } from './src/middleware/errorHandler.js';
import imageRoutes from './src/routes/imageRoutes.js';
import voiceRoutes from './src/routes/voiceRoutes.js';
import settingsRoutes from './src/routes/settingsRoutes.js';



// Get __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(
  cors({
    origin: "http://localhost:5173",
    credentials: true,
  })
);
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// ============================================ //
// API ROUTES                                   //
// ============================================ //

// Auth routes
app.use('/api/auth', authRoutes);

// Chat routes
app.use('/api/chat', chatRoutes);

// voiceRoutes
app.use('/api/voice', voiceRoutes);

// Image routes
app.use('/api/image', imageRoutes);

// Subscription routes
app.use('/api/subscription', subscriptionRoutes);

// Settings routes
app.use('/api/settings', settingsRoutes);



// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: ' Cupid is running!',
    timestamp: new Date().toISOString()
  });
});

// ============================================ //
// PASSWORD RESET PAGE                          //
// ============================================ //
app.get('/reset-password', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'reset-password.html'));
});

// ============================================ //
// CATCH-ALL ROUTE (MUST be LAST)               //
// ============================================ //
app.get('*', (req, res) => {
  // Skip API routes
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ error: 'API endpoint not found' });
  }
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handler 
app.use(errorHandler);

// Start server
connectDB().then(() => {
  app.listen(PORT, () => {
    console.log(` Cupid is listening on port ${PORT}`);
    console.log(` http://localhost:${PORT}`);
    console.log(` Health check: http://localhost:${PORT}/api/health`);
  });
}).catch((error) => {
  console.error(' Failed to connect to database:', error);
  process.exit(1);
});