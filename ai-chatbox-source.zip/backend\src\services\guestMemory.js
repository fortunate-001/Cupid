const guestSessions = new Map();

/**
 * Get previous messages
 */
export function getGuestHistory(sessionId) {
  if (!guestSessions.has(sessionId)) {
    guestSessions.set(sessionId, []);
  }

  return guestSessions.get(sessionId).map(msg => ({
    role: msg.role,
    content: msg.content,
  }));
}
/**
 * Save one message
 */
export function addGuestMessage(sessionId, message) {
  if (!guestSessions.has(sessionId)) {
    guestSessions.set(sessionId, []);
  }

  guestSessions.get(sessionId).push(message);
}

/**
 * Delete a conversation
 */
export function clearGuestSession(sessionId) {
  guestSessions.delete(sessionId);
}

/**
 * Cleanup old sessions every hour
 */
setInterval(() => {
  const now = Date.now();

  for (const [id, messages] of guestSessions.entries()) {
    if (!messages.length) continue;

    const last = messages[messages.length - 1];

    if (now - last.timestamp > 1000 * 60 * 60) {
      guestSessions.delete(id);
    }
  }
}, 1000 * 60 * 60);