// src/services/speechService.js

import fs from "fs";
import axios from "axios";

const ASSEMBLYAI_API_KEY =
  process.env.ASSEMBLYAI_API_KEY;

if (!ASSEMBLYAI_API_KEY) {
  console.warn(
    "⚠️ ASSEMBLYAI_API_KEY is not defined in .env"
  );
}

// =========================================
// UPLOAD AUDIO TO ASSEMBLYAI
// =========================================

const uploadAudio = async (filePath) => {
  try {
    const audioData =
      fs.createReadStream(filePath);

    const response = await axios.post(
      "https://api.assemblyai.com/v2/upload",
      audioData,
      {
        headers: {
          authorization:
            ASSEMBLYAI_API_KEY,
          "transfer-encoding":
            "chunked",
        },

        maxBodyLength: Infinity,
        maxContentLength: Infinity,
      }
    );

    return response.data.upload_url;
  } catch (error) {
    console.error(
      "❌ Audio upload failed:",
      error.response?.data ||
        error.message
    );

    throw error;
  }
};

// =========================================
// START TRANSCRIPTION
// =========================================

const startTranscription = async (
  audioUrl
) => {
  try {
    const response = await axios.post(
      "https://api.assemblyai.com/v2/transcript",

      {
        audio_url: audioUrl,

        // IMPORTANT:
        // speech_model is deprecated.
        // Use speech_models instead.
        speech_models: [
          "universal-3-5-pro",
          "universal-2",
        ],
      },

      {
        headers: {
          authorization:
            ASSEMBLYAI_API_KEY,

          "content-type":
            "application/json",
        },
      }
    );

    return response.data;
  } catch (error) {
    console.error(
      "❌ Failed to start transcription:",
      error.response?.data ||
        error.message
    );

    throw error;
  }
};

// =========================================
// WAIT FOR TRANSCRIPTION
// =========================================

const waitForTranscription = async (
  transcriptId
) => {
  while (true) {
    try {
      const response =
        await axios.get(
          `https://api.assemblyai.com/v2/transcript/${transcriptId}`,
          {
            headers: {
              authorization:
                ASSEMBLYAI_API_KEY,
            },
          }
        );

      const data = response.data;

      // -------------------------------
      // COMPLETED
      // -------------------------------

      if (
        data.status ===
        "completed"
      ) {
        console.log(
          "✅ AssemblyAI transcription completed"
        );

        return data.text || "";
      }

      // -------------------------------
      // ERROR
      // -------------------------------

      if (
        data.status === "error"
      ) {
        throw new Error(
          data.error ||
            "AssemblyAI transcription failed"
        );
      }

      // -------------------------------
      // STILL PROCESSING
      // -------------------------------

      console.log(
        `⏳ Transcription status: ${data.status}`
      );

      await new Promise(
        (resolve) =>
          setTimeout(
            resolve,
            1000
          )
      );
    } catch (error) {
      console.error(
        "❌ Error checking transcription:",
        error.response?.data ||
          error.message
      );

      throw error;
    }
  }
};

// =========================================
// MAIN TRANSCRIPTION FUNCTION
// =========================================

export const transcribeAudio = async (
  filePath
) => {
  try {
    console.log(
      "🎤 Uploading audio to AssemblyAI..."
    );

    // -------------------------------
    // 1. Upload audio
    // -------------------------------

    const audioUrl =
      await uploadAudio(
        filePath
      );

    console.log(
      "✅ Audio uploaded:",
      audioUrl
    );

    // -------------------------------
    // 2. Start transcription
    // -------------------------------

    console.log(
      "📝 Starting transcription..."
    );

    const transcript =
      await startTranscription(
        audioUrl
      );

    console.log(
      "🆔 Transcript ID:",
      transcript.id
    );

    // -------------------------------
    // 3. Wait for result
    // -------------------------------

    console.log(
      "⏳ Waiting for transcription..."
    );

    const text =
      await waitForTranscription(
        transcript.id
      );

    console.log(
      "✅ Transcription:",
      text
    );

    return text;
  } catch (error) {
    console.error(
      "❌ AssemblyAI error:",
      error.response?.data ||
        error.message
    );

    throw error;
  } finally {
    // -------------------------------
    // DELETE TEMP AUDIO FILE
    // -------------------------------

    try {
      if (
        fs.existsSync(filePath)
      ) {
        fs.unlinkSync(
          filePath
        );

        console.log(
          "🗑️ Temporary audio file deleted"
        );
      }
    } catch (error) {
      console.error(
        "⚠️ Could not delete temporary audio:",
        error.message
      );
    }
  }
};