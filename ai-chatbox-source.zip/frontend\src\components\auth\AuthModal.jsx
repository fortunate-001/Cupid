import { useNavigate } from "react-router-dom";

export default function AuthModal({ onGuest }) {

  const navigate = useNavigate();

  return (

    <div className="auth-overlay">

      <div className="auth-modal">

        <h1>Cupid</h1>

        <p>
          Welcome to Cupid.
          Sign in to sync your chats across devices,
          or continue as a guest.
        </p>

        <button
          className="auth-btn google"
          onClick={() => {
            // Google OAuth (next)
          }}
        >
          Continue with Google
        </button>

        <button
          className="auth-btn"
          onClick={() => navigate("/login")}
        >
          Continue with Email
        </button>

        <button
          className="guest-btn"
          onClick={onGuest}
        >
          Continue as Guest
        </button>

      </div>

    </div>

  );

}