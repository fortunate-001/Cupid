import {
  useState,
  useRef,
} from "react";

import { useChat } from "../../context/ChatContext";

import {
  FiPlus,
  FiFile,
} from "react-icons/fi";

import {
  LuImagePlus,
} from "react-icons/lu";

import {
  HiOutlineMicrophone,
} from "react-icons/hi2";

import {
  IoArrowUp,
} from "react-icons/io5";

import api from "../../api/client";

import "../../styles/input.css";


export default function MessageInput({
  disabled,
}) {

  const { send } = useChat();


  const [message, setMessage] =
    useState("");

  const [showMenu, setShowMenu] =
    useState(false);

  const [selectedImage, setSelectedImage] =
    useState(null);

  const [isRecording, setIsRecording] =
    useState(false);

  const [isTranscribing, setIsTranscribing] =
    useState(false);


  const imageInputRef =
    useRef(null);

  const fileInputRef =
    useRef(null);

  const textareaRef =
    useRef(null);

  const mediaRecorderRef =
    useRef(null);

  const audioChunksRef =
    useRef([]);


  // =========================================
  // TEXTAREA RESIZE
  // =========================================

  const autoResize = (e) => {

    const textarea =
      e.target;

    textarea.style.height =
      "auto";

    const newHeight =
      Math.min(
        textarea.scrollHeight,
        180
      );

    textarea.style.height =
      `${newHeight}px`;

    setMessage(
      textarea.value
    );
  };


  // =========================================
  // SEND
  // =========================================

  const handleSend = async () => {

    if (
      (!message.trim() &&
        !selectedImage) ||
      disabled ||
      isRecording ||
      isTranscribing
    ) {
      return;
    }


    const text =
      message.trim();


    const image =
      selectedImage;


    // Clear input immediately

    setMessage("");

    setSelectedImage(null);

    if (textareaRef.current) {

      textareaRef.current.style.height =
        "24px";
    }


    setShowMenu(false);


    // Send text + image

    await send(
      text,
      image
    );
  };


  // =========================================
  // ENTER TO SEND
  // =========================================

  const handleKeyDown = (e) => {

    if (
      e.key === "Enter" &&
      !e.shiftKey
    ) {

      e.preventDefault();

      handleSend();
    }
  };


  // =========================================
  // START RECORDING
  // =========================================

  const startRecording =
    async () => {

      try {

        if (
          disabled ||
          isTranscribing
        ) {
          return;
        }


        const stream =
          await navigator.mediaDevices
            .getUserMedia({
              audio: true,
            });


        const mediaRecorder =
          new MediaRecorder(
            stream
          );


        mediaRecorderRef.current =
          mediaRecorder;


        audioChunksRef.current =
          [];


        mediaRecorder.ondataavailable =
          (event) => {

            if (
              event.data.size > 0
            ) {

              audioChunksRef.current
                .push(event.data);
            }
          };


        mediaRecorder.onstop =
          async () => {

            stream
              .getTracks()
              .forEach(
                (track) =>
                  track.stop()
              );


            const audioBlob =
              new Blob(
                audioChunksRef.current,
                {
                  type:
                    mediaRecorder.mimeType ||
                    "audio/webm",
                }
              );


            await transcribeAudio(
              audioBlob
            );
          };


        mediaRecorder.start();

        setIsRecording(true);

        console.log(
          "🎤 Recording started"
        );

      } catch (error) {

        console.error(
          "❌ Microphone error:",
          error
        );

        alert(
          "Cupid needs microphone permission to use voice."
        );
      }
    };


  // =========================================
  // STOP RECORDING
  // =========================================

  const stopRecording = () => {

    if (
      !mediaRecorderRef.current ||
      !isRecording
    ) {
      return;
    }


    mediaRecorderRef.current.stop();

    setIsRecording(false);

    console.log(
      "🛑 Recording stopped"
    );
  };


  // =========================================
  // TOGGLE RECORDING
  // =========================================

  const toggleRecording = () => {

    if (isRecording) {

      stopRecording();

    } else {

      startRecording();
    }
  };


  // =========================================
  // TRANSCRIBE AUDIO
  // =========================================

  const transcribeAudio =
    async (audioBlob) => {

      try {

        setIsTranscribing(true);


        const formData =
          new FormData();


        formData.append(
          "audio",
          audioBlob,
          "voice-message.webm"
        );


        const response =
          await api.post(
            "/voice/transcribe",
            formData,
            {
              headers: {
                "Content-Type":
                  "multipart/form-data",
              },
            }
          );


        const text =
          response.data?.text ||
          "";


        if (text.trim()) {

          setMessage(text);


          setTimeout(() => {

            textareaRef.current
              ?.focus();

          }, 50);
        }

      } catch (error) {

        console.error(
          "❌ Transcription failed:",
          error.response?.data ||
            error.message
        );

        alert(
          "Cupid couldn't understand the recording. Please try again."
        );

      } finally {

        setIsTranscribing(false);
      }
    };


  // =========================================
  // IMAGE UPLOAD
  // =========================================

  const handleImageUpload =
    (e) => {

      const file =
        e.target.files?.[0];


      if (!file) {
        return;
      }


      // Security / validation

      if (
        !file.type.startsWith(
          "image/"
        )
      ) {

        alert(
          "Please select a valid image."
        );

        return;
      }


      // Limit to 10 MB

      if (
        file.size >
        10 * 1024 * 1024
      ) {

        alert(
          "Image must be smaller than 10MB."
        );

        return;
      }


      console.log(
        "🖼️ Selected image:",
        file
      );


      setSelectedImage(file);

      setShowMenu(false);


      // Allow selecting same image again

      e.target.value = "";
    };


  // =========================================
  // REMOVE SELECTED IMAGE
  // =========================================

  const removeSelectedImage =
    () => {

      setSelectedImage(null);
    };


  // =========================================
  // FILE UPLOAD
  // =========================================

  const handleFileUpload =
    (e) => {

      const file =
        e.target.files?.[0];


      if (!file) {
        return;
      }


      console.log(
        "Selected file:",
        file
      );


      setShowMenu(false);

      e.target.value = "";
    };


  // =========================================
  // IMAGE PREVIEW
  // =========================================

  const imagePreview =
    selectedImage
      ? URL.createObjectURL(
          selectedImage
        )
      : null;


  return (
    <div className="message-input-container">

      {/* =====================================
          IMAGE PREVIEW
      ===================================== */}

      {selectedImage && (
        <div className="selected-image-preview">

          <div className="selected-image-box">

            <img
              src={imagePreview}
              alt="Selected"
            />

            <button
              type="button"
              onClick={
                removeSelectedImage
              }
              className="remove-image-btn"
            >
              ×
            </button>

          </div>

        </div>
      )}


      <div className="message-input">


        {/* ===================================
            ATTACHMENT
        =================================== */}

        <div className="attachment-wrapper">

          <button
            type="button"
            className="input-icon"
            disabled={
              disabled ||
              isRecording ||
              isTranscribing
            }
            onClick={() =>
              setShowMenu(
                (prev) =>
                  !prev
              )
            }
          >
            <FiPlus />
          </button>


          {showMenu &&
            !disabled &&
            !isRecording &&
            !isTranscribing && (

              <div className="attachment-menu">

                <button
                  type="button"
                  onClick={() =>
                    imageInputRef.current?.click()
                  }
                >

                  <LuImagePlus />

                  <span>
                    Upload Image
                  </span>

                </button>


                <button
                  type="button"
                  onClick={() =>
                    fileInputRef.current?.click()
                  }
                >

                  <FiFile />

                  <span>
                    Upload File
                  </span>

                </button>

              </div>
            )}

        </div>


        {/* ===================================
            TEXTAREA
        =================================== */}

        <textarea
          ref={textareaRef}
          className="message-textarea"
          rows="1"
          value={message}
          disabled={
            disabled ||
            isRecording
          }
          placeholder={
            isRecording
              ? "Listening..."
              : isTranscribing
              ? "Transcribing..."
              : selectedImage
              ? "Ask Cupid about this image..."
              : "Message Cupid..."
          }
          onChange={autoResize}
          onKeyDown={handleKeyDown}
        />


        {/* ===================================
            MICROPHONE
        =================================== */}

        <button
          type="button"
          className={
            isRecording
              ? "input-icon microphone-btn recording"
              : "input-icon microphone-btn"
          }
          disabled={
            disabled ||
            isTranscribing
          }
          title={
            isRecording
              ? "Stop recording"
              : "Voice message"
          }
          onClick={
            toggleRecording
          }
        >
          <HiOutlineMicrophone />
        </button>


        {/* ===================================
            SEND
        =================================== */}

        <button
          type="button"
          className={
            message.trim() ||
            selectedImage
              ? "send-btn active"
              : "send-btn"
          }
          disabled={
            (!message.trim() &&
              !selectedImage) ||
            disabled ||
            isRecording ||
            isTranscribing
          }
          onClick={
            handleSend
          }
        >
          <IoArrowUp />
        </button>


        {/* ===================================
            IMAGE INPUT
        =================================== */}

        <input
          ref={imageInputRef}
          type="file"
          accept="image/*"
          hidden
          onChange={
            handleImageUpload
          }
        />


        {/* ===================================
            FILE INPUT
        =================================== */}

        <input
          ref={fileInputRef}
          type="file"
          hidden
          onChange={
            handleFileUpload
          }
        />

      </div>
    </div>
  );
}