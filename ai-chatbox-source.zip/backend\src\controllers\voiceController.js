// src/controllers/voiceController.js

import {
  transcribeAudio,
  textToSpeech,
} from "../services/aiService.js";


// ======================================================
// TRANSCRIBE VOICE
// ======================================================

export const transcribeVoice =
  async (req, res) => {
    try {
      console.log(
        "🎤 Voice transcription request received"
      );

      if (!req.file) {
        return res.status(400).json({
          error:
            "No audio file was provided.",
        });
      }

      console.log(
        "🎤 Audio file:",
        req.file.originalname
      );

      console.log(
        "🎤 Audio type:",
        req.file.mimetype
      );

      console.log(
        "🎤 Audio size:",
        req.file.size
      );

      const result =
        await transcribeAudio(
          req.file.buffer
        );

      if (!result.success) {
        return res.status(500).json({
          error:
            result.error ||
            "Failed to transcribe audio.",
        });
      }

      return res.json({
        success: true,

        text:
          result.text || "",
      });

    } catch (error) {
      console.error(
        "❌ Voice transcription controller error:",
        error
      );

      return res.status(500).json({
        error:
          error.message ||
          "Failed to transcribe audio.",
      });
    }
  };


// ======================================================
// TEXT TO SPEECH
// ======================================================

export const speak =
  async (req, res) => {
    try {
      console.log(
        "🔊 Text-to-speech request received"
      );

      const {
        text,
        voicePreference,
      } = req.body;

      if (
        !text ||
        !text.trim()
      ) {
        return res.status(400).json({
          error:
            "Text is required.",
        });
      }

      // =========================================
      // VALIDATE VOICE
      // =========================================

      const voice =
        voicePreference === "male"
          ? "male"
          : "female";

      console.log(
        "🔊 Selected voice:",
        voice
      );

      // =========================================
      // GENERATE SPEECH
      // =========================================

      const result =
        await textToSpeech(
          text.trim(),
          voice
        );

      if (!result.success) {
        return res.status(500).json({
          error:
            result.error ||
            "Failed to generate speech.",
        });
      }

      return res.json({
        success: true,

        audio:
          result.audio,

        mimeType:
          result.mimeType ||
          "audio/mpeg",

        voice,
      });

    } catch (error) {
      console.error(
        "❌ Text-to-speech controller error:",
        error
      );

      return res.status(500).json({
        error:
          error.message ||
          "Failed to generate speech.",
      });
    }
  };


export default {
  transcribeVoice,
  speak,
};