import { createContext, useContext, useEffect, useState } from "react";

const ThemeContext = createContext();

export function ThemeProvider({ children }) {
  const [theme, setTheme] = useState(
    localStorage.getItem("theme") || "dark"
  );

  const [accent, setAccent] = useState(
    localStorage.getItem("accent") || "#10b981"
  );

  useEffect(() => {
    document.body.classList.toggle(
      "light",
      theme === "light"
    );

    document.documentElement.style.setProperty(
      "--accent",
      accent
    );

    localStorage.setItem("theme", theme);
    localStorage.setItem("accent", accent);
  }, [theme, accent]);

  return (
    <ThemeContext.Provider
      value={{
        theme,
        setTheme,
        accent,
        setAccent,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);