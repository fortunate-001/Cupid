// src/routes/imageRoutes.js

import express from "express";
import { createImage } from "../controllers/imageController.js";
import auth from "../middleware/authMiddleware.js";

const router = express.Router();

router.post("/generate", auth, createImage);

export default router;