import {
  useEffect,
  useState,
} from "react";

import {
  FiSettings,
  FiUser,
  FiShield,
  FiVolume2,
  FiCheck,
} from "react-icons/fi";

import {
  HiOutlinePaintBrush,
} from "react-icons/hi2";

import {
  LuBrain,
} from "react-icons/lu";

import api from "../api/client";

const tabs = [
  {
    name: "General",
    icon: <FiSettings />,
  },

  {
    name: "Appearance",
    icon: <HiOutlinePaintBrush />,
  },

  {
    name: "Profile",
    icon: <FiUser />,
  },

  {
    name: "Memory",
    icon: <LuBrain />,
  },

  {
    name: "Account",
    icon: <FiShield />,
  },
];


export default function SettingsContent() {

  const [
    activeTab,
    setActiveTab,
  ] = useState("General");


  const [
    loading,
    setLoading,
  ] = useState(true);


  const [
    saving,
    setSaving,
  ] = useState(false);


  const [
    settings,
    setSettings,
  ] = useState({
    name: "",
    email: "",

    aiSettings: {
      personality: "friendly",

      responseStyle:
        "normal",

      language:
        "English",

      rememberConversations:
        true,

      voiceGender:
        "female",

      voiceEnabled:
        true,
    },

    subscription: {
      tier: "free",
    },
  });


  // =========================================
  // LOAD SETTINGS
  // =========================================

  useEffect(() => {

    loadSettings();

  }, []);


  const loadSettings =
    async () => {

      try {

        setLoading(true);

        const response =
          await api.get(
            "/settings"
          );

        if (
          response.data?.settings
        ) {

          setSettings(
            response.data.settings
          );
        }

      } catch (error) {

        console.error(
          "❌ Failed to load settings:",
          error.response?.data ||
            error.message
        );

      } finally {

        setLoading(false);

      }
    };


  // =========================================
  // SAVE SETTING
  // =========================================

  const updateSetting =
    async (
      key,
      value
    ) => {

      try {

        setSaving(true);

        setSettings(
          (prev) => ({
            ...prev,

            aiSettings: {
              ...prev.aiSettings,

              [key]:
                value,
            },
          })
        );


        const response =
          await api.put(
            "/settings",
            {
              [key]:
                value,
            }
          );


        if (
          response.data?.settings
        ) {

          setSettings(
            response.data.settings
          );
        }

      } catch (error) {

        console.error(
          "❌ Failed to update setting:",
          error.response?.data ||
            error.message
        );

        await loadSettings();

      } finally {

        setSaving(false);

      }
    };


  // =========================================
  // PROFILE UPDATE
  // =========================================

  const updateProfile =
    async (
      field,
      value
    ) => {

      try {

        setSaving(true);

        const response =
          await api.put(
            "/settings/profile",
            {
              [field]:
                value,
            }
          );


        if (
          response.data?.user
        ) {

          setSettings(
            (prev) => ({
              ...prev,

              name:
                response.data.user
                  .name,

              email:
                response.data.user
                  .email,

              avatar:
                response.data.user
                  .avatar,
            })
          );
        }

      } catch (error) {

        console.error(
          "❌ Profile update failed:",
          error.response?.data ||
            error.message
        );

      } finally {

        setSaving(false);

      }
    };


  // =========================================
  // LOADING
  // =========================================

  if (loading) {

    return (
      <div className="settings-loading">
        Loading settings...
      </div>
    );
  }


  // =========================================
  // GENERAL
  // =========================================

  const renderGeneral =
    () => (

      <div className="settings-section">

        <div className="settings-section-title">

          <h3>
            General
          </h3>

          <p>
            Customize how Cupid responds to you.
          </p>

        </div>


        {/* PERSONALITY */}

        <div className="setting-item">

          <div>

            <strong>
              Personality
            </strong>

            <span>
              Choose Cupid's personality.
            </span>

          </div>


          <select

            value={
              settings.aiSettings
                ?.personality ||
              "friendly"
            }

            onChange={(e) =>
              updateSetting(
                "personality",
                e.target.value
              )
            }

          >

            <option value="friendly">
              Friendly
            </option>

            <option value="professional">
              Professional
            </option>

            <option value="casual">
              Casual
            </option>

            <option value="creative">
              Creative
            </option>

          </select>

        </div>


        {/* RESPONSE STYLE */}

        <div className="setting-item">

          <div>

            <strong>
              Response style
            </strong>

            <span>
              Choose how detailed Cupid should be.
            </span>

          </div>


          <select

            value={
              settings.aiSettings
                ?.responseStyle ||
              "normal"
            }

            onChange={(e) =>
              updateSetting(
                "responseStyle",
                e.target.value
              )
            }

          >

            <option value="short">
              Short
            </option>

            <option value="normal">
              Normal
            </option>

            <option value="detailed">
              Detailed
            </option>

          </select>

        </div>


        {/* LANGUAGE */}

        <div className="setting-item">

          <div>

            <strong>
              Language
            </strong>

            <span>
              Language used by Cupid.
            </span>

          </div>


          <select

            value={
              settings.aiSettings
                ?.language ||
              "English"
            }

            onChange={(e) =>
              updateSetting(
                "language",
                e.target.value
              )
            }

          >

            <option>
              English
            </option>

            <option>
              French
            </option>

            <option>
              Spanish
            </option>

            <option>
              Portuguese
            </option>

          </select>

        </div>


        {/* VOICE */}

        <div className="setting-item voice-setting">

          <div>

            <strong>
              <FiVolume2 />

              Voice
            </strong>

            <span>
              Choose the voice Cupid uses when reading responses.
            </span>

          </div>


          <div className="voice-options">

            <button

              type="button"

              className={
                settings.aiSettings
                  ?.voiceGender ===
                "female"
                  ? "voice-option active"
                  : "voice-option"
              }

              onClick={() =>
                updateSetting(
                  "voiceGender",
                  "female"
                )
              }

            >

              <span>
                ♀
              </span>

              Female

              {settings.aiSettings
                ?.voiceGender ===
                "female" && (
                <FiCheck />
              )}

            </button>


            <button

              type="button"

              className={
                settings.aiSettings
                  ?.voiceGender ===
                "male"
                  ? "voice-option active"
                  : "voice-option"
              }

              onClick={() =>
                updateSetting(
                  "voiceGender",
                  "male"
                )
              }

            >

              <span>
                ♂
              </span>

              Male

              {settings.aiSettings
                ?.voiceGender ===
                "male" && (
                <FiCheck />
              )}

            </button>

          </div>

        </div>


        {/* VOICE ENABLED */}

        <div className="setting-item">

          <div>

            <strong>
              Voice responses
            </strong>

            <span>
              Allow Cupid to read responses aloud.
            </span>

          </div>


          <button

            type="button"

            className={
              settings.aiSettings
                ?.voiceEnabled
                ? "settings-toggle active"
                : "settings-toggle"
            }

            onClick={() =>
              updateSetting(
                "voiceEnabled",
                !settings.aiSettings
                  ?.voiceEnabled
              )
            }

          >

            <span />

          </button>

        </div>

      </div>
    );


  // =========================================
  // APPEARANCE
  // =========================================

  const renderAppearance =
    () => (

      <div className="settings-section">

        <div className="settings-section-title">

          <h3>
            Appearance
          </h3>

          <p>
            Customize how Cupid looks.
          </p>

        </div>


        <div className="setting-item">

          <div>

            <strong>
              Theme
            </strong>

            <span>
              Choose your preferred theme.
            </span>

          </div>


          <select>

            <option>
              System
            </option>

            <option>
              Light
            </option>

            <option>
              Dark
            </option>

          </select>

        </div>

      </div>
    );


  // =========================================
  // PROFILE
  // =========================================

  const renderProfile =
    () => (

      <div className="settings-section">

        <div className="settings-section-title">

          <h3>
            Profile
          </h3>

          <p>
            Manage your personal information.
          </p>

        </div>


        <div className="profile-form">

          <label>
            Name
          </label>

          <input

            type="text"

            value={
              settings.name ||
              ""
            }

            onChange={(e) =>
              setSettings(
                (prev) => ({
                  ...prev,

                  name:
                    e.target.value,
                })
              )
            }

            onBlur={() =>
              updateProfile(
                "name",
                settings.name
              )
            }

          />


          <label>
            Email
          </label>

          <input

            type="email"

            value={
              settings.email ||
              ""
            }

            disabled

          />

        </div>

      </div>
    );


  // =========================================
  // MEMORY
  // =========================================

  const renderMemory =
    () => (

      <div className="settings-section">

        <div className="settings-section-title">

          <h3>
            Memory
          </h3>

          <p>
            Control how Cupid remembers your conversations.
          </p>

        </div>


        <div className="setting-item">

          <div>

            <strong>
              Remember conversations
            </strong>

            <span>
              Allow Cupid to use saved memories when responding.
            </span>

          </div>


          <button

            type="button"

            className={
              settings.aiSettings
                ?.rememberConversations
                ? "settings-toggle active"
                : "settings-toggle"
            }

            onClick={() =>
              updateSetting(
                "rememberConversations",
                !settings.aiSettings
                  ?.rememberConversations
              )
            }

          >

            <span />

          </button>

        </div>

      </div>
    );


  // =========================================
  // ACCOUNT
  // =========================================

  const renderAccount =
    () => (

      <div className="settings-section">

        <div className="settings-section-title">

          <h3>
            Account
          </h3>

          <p>
            View your account information.
          </p>

        </div>


        <div className="account-card">

          <div>

            <strong>
              Current plan
            </strong>

            <span>
              {settings.subscription
                ?.tier ||
                "free"}
            </span>

          </div>

        </div>


        <div className="account-card">

          <div>

            <strong>
              Email
            </strong>

            <span>
              {settings.email}
            </span>

          </div>

        </div>

      </div>
    );


  // =========================================
  // CONTENT
  // =========================================

  return (

    <div className="settings-layout">

      <aside className="settings-sidebar">

        {tabs.map((tab) => (

          <button

            key={tab.name}

            className={
              activeTab === tab.name
                ? "tab active"
                : "tab"
            }

            onClick={() =>
              setActiveTab(
                tab.name
              )
            }

          >

            {tab.icon}

            <span>
              {tab.name}
            </span>

          </button>

        ))}

      </aside>


      <section className="settings-content">

        {activeTab ===
          "General" &&
          renderGeneral()}


        {activeTab ===
          "Appearance" &&
          renderAppearance()}


        {activeTab ===
          "Profile" &&
          renderProfile()}


        {activeTab ===
          "Memory" &&
          renderMemory()}


        {activeTab ===

          "Account" &&
          renderAccount()}


        {saving && (

          <div className="settings-saving">
            Saving...
          </div>

        )}

      </section>

    </div>
  );
}