// src/controllers/imageController.js

import { generateImage } from "../services/imageService.js";
import Message from "../models/Message.js";
import connectDB from "../../lib/mongodb.js";

export const createImage = async (req, res) => {
  try {
    await connectDB();

    const { prompt, sessionId } = req.body;
    const user = req.user;

    if (!prompt?.trim()) {
      return res.status(400).json({
        success: false,
        message: "Image prompt is required.",
      });
    }

    const image = await generateImage(prompt);

    if (user) {
      await Message.create({
        userId: user._id,
        role: "assistant",
        content: prompt,
        sessionId,
        isImage: true,
        imageUrl: image.url,
      });

      user.usage.totalImagesGenerated =
        (user.usage.totalImagesGenerated || 0) + 1;

      await user.save();
    }

    res.json({
      success: true,
      imageUrl: image.url,
      revisedPrompt: image.revised_prompt || prompt,
    });
  } catch (error) {
    console.error("❌ Image Controller:", error);

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};