import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import { FaEye, FaEyeSlash, FaRobot } from "react-icons/fa";
import { toast } from "react-hot-toast";

import { useAuth } from "../context/AuthContext";

import "../styles/auth.css";

export default function Register() {

  const navigate = useNavigate();

  const { register } = useAuth();

  const [showPassword, setShowPassword] =
    useState(false);

  const formik = useFormik({

    initialValues:{

      name:"",
      email:"",
      password:"",

    },

    validationSchema:Yup.object({

      name:Yup.string()
      .required("Full name is required"),

      email:Yup.string()
      .email("Invalid email")
      .required("Email is required"),

      password:Yup.string()
      .min(6,"Minimum 6 characters")
      .required("Password is required"),

    }),

    onSubmit:async(values,{setSubmitting})=>{

      try{

        await register(values);

        sessionStorage.removeItem(
          "guest_mode"
        );

        toast.success(
          "Account created successfully!"
        );

        navigate("/chat",{
          replace:true,
        });

      }

      catch(err){

        toast.error(

          err.response?.data?.error ||

          "Registration failed"

        );

      }

      finally{

        setSubmitting(false);

      }

    }

  });

  return(

    <div className="register-page">

      <div className="register-card">

        <div className="login-logo">

          <FaRobot/>

        </div>

        <h1>Create Account</h1>

        <p>
          Join Cupid AI
        </p>

        <form onSubmit={formik.handleSubmit}>

          <div className="input-group">

            <label>Full Name</label>

            <input

              name="name"

              placeholder="Your name"

              value={formik.values.name}

              onChange={formik.handleChange}

              onBlur={formik.handleBlur}

            />

            {formik.touched.name &&
            formik.errors.name &&(

              <small className="error">

                {formik.errors.name}

              </small>

            )}

          </div>

          <div className="input-group">

            <label>Email</label>

            <input

              name="email"

              type="email"

              placeholder="Email"

              value={formik.values.email}

              onChange={formik.handleChange}

              onBlur={formik.handleBlur}

            />

            {formik.touched.email &&
            formik.errors.email &&(

              <small className="error">

                {formik.errors.email}

              </small>

            )}

          </div>

          <div className="input-group">

            <label>Password</label>

            <div className="password-box">

              <input

                name="password"

                type={
                  showPassword
                  ? "text"
                  : "password"
                }

                placeholder="Password"

                value={formik.values.password}

                onChange={formik.handleChange}

                onBlur={formik.handleBlur}

              />

              <button

                type="button"

                onClick={()=>setShowPassword(!showPassword)}

              >

                {showPassword

                ? <FaEyeSlash/>

                : <FaEye/>}

              </button>

            </div>

            {formik.touched.password &&
            formik.errors.password &&(

              <small className="error">

                {formik.errors.password}

              </small>

            )}

          </div>

          <button

            type="submit"

            className="register-btn"

            disabled={formik.isSubmitting}

          >

            {formik.isSubmitting

            ? "Creating..."

            : "Create Account"}

          </button>

        </form>

        <p className="bottom-text">

          Already have an account?

          <Link to="/login">

            Login

          </Link>

        </p>

      </div>

    </div>

  );

}