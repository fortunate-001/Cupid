// src/components/settings/tabs/AboutTab.jsx
import React from 'react';

const AboutTab = () => {
  return (
    <div className="settings-panel">
      <h3>About</h3>
      <p className="settings-subtitle">Learn more about Cupid</p>
      
      <div className="settings-group">
        <p><strong>Version:</strong> 1.0.0</p>
        <p><strong>Description:</strong> Cupid is an AI assistant powered by Groq's Llama 3 model.</p>
        <p><strong>Features:</strong></p>
        <ul style={{ color: 'var(--text-secondary)', paddingLeft: '20px', marginTop: '8px' }}>
          <li>AI-powered conversations</li>
          <li>Chat history</li>
          <li>Customizable themes</li>
          <li>Guest mode</li>
        </ul>
      </div>
    </div>
  );
};

export default AboutTab;