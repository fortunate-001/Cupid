// src/middleware/errorHandler.js
export const errorHandler = (err, req, res, next) => {
  console.error(' Error:', err.message);
  console.error(' Stack:', err.stack);

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal server error';

  res.status(statusCode).json({
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};