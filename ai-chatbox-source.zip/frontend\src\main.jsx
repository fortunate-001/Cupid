import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";

import { ThemeProvider } from "./context/ThemeContext";
import { AuthProvider } from "./context/AuthContext";

import App from "./App";

import "./styles/globals.css";
import "./styles/theme.css";
import "./styles/theme.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>

      <ThemeProvider>

        <AuthProvider>

          <Toaster position="top-right" />

          <App />

        </AuthProvider>

      </ThemeProvider>

    </BrowserRouter>
  </React.StrictMode>
);