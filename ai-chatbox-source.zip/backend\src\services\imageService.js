// src/services/imageService.js

import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function generateImage(prompt) {
  try {
    console.log("=================================");
    console.log("🎨 IMAGE GENERATION STARTED");
    console.log("Prompt:", prompt);
    console.log(
      "OpenAI Key:",
      process.env.OPENAI_API_KEY ? "Loaded ✅" : "Missing ❌"
    );
    console.log("=================================");

    const response = await openai.images.generate({
      model: "gpt-image-1",
      prompt,
      size: "1024x1024",
    });

    console.log("✅ OpenAI Response:");
    console.dir(response, { depth: null });

    if (!response.data || response.data.length === 0) {
      throw new Error("No image returned from OpenAI.");
    }

    return {
      success: true,
      imageUrl: response.data[0].url,
      revisedPrompt: response.data[0].revised_prompt || prompt,
    };
  } catch (error) {
    console.error("=================================");
    console.error("❌ IMAGE GENERATION FAILED");
    console.error(error);

    if (error.response) {
      console.error("Status:", error.response.status);
      console.error("Data:", error.response.data);
    }

    console.error("=================================");

    return {
      success: false,
      error: error.message,
    };
  }
}

export async function editImage(image, prompt) {
  const response = await openai.images.edit({
    model: "gpt-image-1",
    image,
    prompt,
  });

  return response.data[0];
}

export async function generateImageVariations(image) {
  const response = await openai.images.createVariation({
    image,
    n: 4,
    size: "1024x1024",
  });

  return response.data;
}