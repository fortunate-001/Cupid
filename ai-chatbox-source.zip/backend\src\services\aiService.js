// src/services/aiService.js

import axios from "axios";
import OpenAI from "openai";

import modelService from "./modelService.js";
import buildSystemPrompt from "../prompts/systemPrompt.js";

const groqApiKey = process.env.GROQ_API_KEY;
const openaiApiKey = process.env.OPENAI_API_KEY;
const removeBgApiKey = process.env.REMOVE_BG_API_KEY;
const assemblyApiKey = process.env.ASSEMBLYAI_API_KEY;
const elevenApiKey = process.env.ELEVENLABS_API_KEY;

const openai = openaiApiKey
  ? new OpenAI({
      apiKey: openaiApiKey,
    })
  : null;


// ======================================================
// GROQ CHAT
// ======================================================

export async function callGroqAI(
  userMessage,
  userName = "User",
  conversationHistory = [],
  memories = []
) {
  try {
    if (!groqApiKey) {
      throw new Error("GROQ_API_KEY is missing.");
    }

    const messages = [
      {
        role: "system",
        content: buildSystemPrompt(
          userName,
          memories
        ),
      },
    ];

    if (Array.isArray(conversationHistory)) {
      messages.push(...conversationHistory);
    }

    messages.push({
      role: "user",
      content: userMessage,
    });

    console.log("🤖 Sending request to Groq...");
    console.log(
      "🧠 Model:",
      modelService.getModel()
    );
    console.log(
      "📚 History:",
      conversationHistory.length
    );
    console.log(
      "💬 Message:",
      userMessage
    );

    const response = await axios.post(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        model: modelService.getModel(),
        messages,
        temperature: modelService.getTemperature(),
        max_tokens: modelService.getMaxTokens(),
      },
      {
        headers: {
          Authorization: `Bearer ${groqApiKey}`,
          "Content-Type": "application/json",
        },
      }
    );

    console.log("✅ Groq response received");

    return (
      response.data?.choices?.[0]?.message?.content ||
      "I couldn't generate a response."
    );

  } catch (error) {
    console.error(
      "❌ GROQ ERROR STATUS:",
      error.response?.status
    );

    console.error(
      "❌ GROQ ERROR DATA:",
      error.response?.data
    );

    console.error(
      "❌ GROQ ERROR MESSAGE:",
      error.message
    );

    throw new Error(
      error.response?.data?.error?.message ||
        error.response?.data?.error ||
        error.message ||
        "Groq request failed."
    );
  }
}


// ======================================================
// IMAGE GENERATION
// ======================================================

export async function generateImage(prompt) {
  try {
    if (!prompt || !prompt.trim()) {
      throw new Error(
        "Image prompt is required."
      );
    }

    const encodedPrompt =
      encodeURIComponent(
        prompt.trim()
      );

    const imageUrl =
      `https://image.pollinations.ai/prompt/${encodedPrompt}` +
      `?width=1024` +
      `&height=1024` +
      `&seed=${Date.now()}` +
      `&model=flux`;

    return {
      success: true,
      imageUrl,
    };

  } catch (error) {
    console.error(
      "❌ Image Generation Error:",
      error
    );

    return {
      success: false,
      error:
        error.message ||
        "Failed to generate image.",
    };
  }
}


// ======================================================
// IMAGE UNDERSTANDING / VISION
// ======================================================

export async function analyzeImage(
  imageBase64,
  userMessage = "Describe this image in detail."
) {
  try {
    if (!groqApiKey) {
      throw new Error(
        "GROQ_API_KEY is missing."
      );
    }

    if (!imageBase64) {
      throw new Error(
        "No image was provided."
      );
    }

    console.log(
      "👁️ Analyzing image with Groq Vision..."
    );

    const response = await axios.post(
      "https://api.groq.com/openai/v1/chat/completions",
      {
        model:
          process.env.GROQ_VISION_MODEL ||
          "meta-llama/llama-4-scout-17b-16e-instruct",

        messages: [
          {
            role: "system",
            content:
              "You are Cupid's vision system. Analyze images accurately and help the user understand, describe, interpret, extract text from, debug, or reason about images. If the user asks about something specific in the image, focus on that. Do not invent details that are not visible.",
          },

          {
            role: "user",

            content: [
              {
                type: "text",
                text:
                  userMessage ||
                  "Describe this image in detail.",
              },

              {
                type: "image_url",

                image_url: {
                  url: imageBase64,
                },
              },
            ],
          },
        ],

        temperature: 0.4,

        max_tokens: 2048,
      },

      {
        headers: {
          Authorization:
            `Bearer ${groqApiKey}`,

          "Content-Type":
            "application/json",
        },
      }
    );

    const result =
      response.data?.choices?.[0]?.message
        ?.content;

    if (!result) {
      throw new Error(
        "Vision model returned no response."
      );
    }

    console.log(
      "✅ Image analysis completed."
    );

    return {
      success: true,
      text: result,
    };

  } catch (error) {
    console.error(
      "❌ Vision Error:",
      error.response?.data ||
        error.message
    );

    return {
      success: false,

      error:
        error.response?.data?.error?.message ||
        error.message ||
        "Failed to analyze image.",
    };
  }
}


// ======================================================
// REMOVE BACKGROUND
// ======================================================

export async function removeBackground(
  imageUrl
) {
  try {
    if (!removeBgApiKey) {
      return {
        success: false,
        error:
          "REMOVE_BG_API_KEY missing",
      };
    }

    if (!imageUrl) {
      return {
        success: false,
        error:
          "Image URL is required.",
      };
    }

    const response = await axios.post(
      "https://api.remove.bg/v1.0/removebg",
      {
        image_url: imageUrl,
        size: "auto",
      },
      {
        headers: {
          "X-Api-Key": removeBgApiKey,
        },

        responseType:
          "arraybuffer",
      }
    );

    const base64 =
      Buffer.from(
        response.data
      ).toString("base64");

    return {
      success: true,

      imageUrl:
        `data:image/png;base64,${base64}`,
    };

  } catch (error) {
    console.error(
      "❌ Remove BG Error:",
      error.message
    );

    return {
      success: false,

      error:
        "Failed to remove background.",
    };
  }
}


// ======================================================
// SPEECH TO TEXT
// ======================================================

export async function transcribeAudio(
  audioBuffer
) {
  try {
    if (!assemblyApiKey) {
      return {
        success: false,

        error:
          "ASSEMBLYAI_API_KEY missing",
      };
    }

    if (!audioBuffer) {
      return {
        success: false,

        error:
          "No audio was provided.",
      };
    }

    console.log(
      "🎤 Uploading audio to AssemblyAI..."
    );

    const upload =
      await axios.post(
        "https://api.assemblyai.com/v2/upload",
        audioBuffer,
        {
          headers: {
            authorization:
              assemblyApiKey,

            "Content-Type":
              "application/octet-stream",
          },

          maxBodyLength:
            Infinity,

          maxContentLength:
            Infinity,
        }
      );

    console.log(
      "🎤 Audio uploaded."
    );

    const transcript =
      await axios.post(
        "https://api.assemblyai.com/v2/transcript",
        {
          audio_url:
            upload.data.upload_url,

          speech_model:
            "universal-2",
        },
        {
          headers: {
            authorization:
              assemblyApiKey,

            "Content-Type":
              "application/json",
          },
        }
      );

    const transcriptId =
      transcript.data.id;

    console.log(
      "📝 Transcript ID:",
      transcriptId
    );

    let result;

    while (true) {
      await new Promise(
        (resolve) =>
          setTimeout(
            resolve,
            2000
          )
      );

      result =
        await axios.get(
          `https://api.assemblyai.com/v2/transcript/${transcriptId}`,
          {
            headers: {
              authorization:
                assemblyApiKey,
            },
          }
        );

      console.log(
        "📝 Transcription status:",
        result.data.status
      );

      if (
        result.data.status ===
        "completed"
      ) {
        break;
      }

      if (
        result.data.status ===
        "error"
      ) {
        throw new Error(
          result.data.error ||
            "AssemblyAI transcription failed."
        );
      }
    }

    return {
      success: true,

      text:
        result.data.text ||
        "",
    };

  } catch (error) {
    console.error(
      "❌ AssemblyAI Error:",
      error.response?.data ||
        error.message
    );

    return {
      success: false,

      error:
        error.response?.data?.error ||
        error.message ||
        "Failed to transcribe audio.",
    };
  }
}

// ======================================================
// TEXT TO SPEECH
// ======================================================

export async function textToSpeech(
  text,
  voicePreference = "female"
) {
  try {
    if (!elevenApiKey) {
      return {
        success: false,
        error:
          "ELEVENLABS_API_KEY missing",
      };
    }

    // =========================================
    // ELEVENLABS VOICES
    // =========================================

    const voices = {
      female:
        "21m00Tcm4TlvDq8ikWAM",

      male:
        "pNInz6obpgDQGcFmaJgB",
    };

    const voiceId =
      voices[voicePreference] ||
      voices.female;

    console.log(
      "🔊 ElevenLabs voice:",
      voicePreference,
      voiceId
    );

    // =========================================
    // GENERATE SPEECH
    // =========================================

    const response =
      await axios.post(
        `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,

        {
          text,

          model_id:
            "eleven_multilingual_v2",

          voice_settings: {
            stability: 0.5,

            similarity_boost: 0.75,

          },
        },

        {
          headers: {
            "xi-api-key":
              elevenApiKey,

            Accept:
              "audio/mpeg",

            "Content-Type":
              "application/json",
          },

          responseType:
            "arraybuffer",
        }
      );

    const audio =
      Buffer.from(
        response.data
      ).toString("base64");

    return {
      success: true,

      audio,

      mimeType:
        "audio/mpeg",

      voice:
        voicePreference,
    };

  } catch (error) {
    console.error(
      "❌ ElevenLabs Error:",
      error.response?.data ||
        error.message
    );

    return {
      success: false,

      error:
        error.response?.data?.detail?.message ||
        error.message ||
        "Failed to generate speech.",
    };
  }
}