// src/components/settings/tabs/GeneralTab.jsx
import React from 'react';

const GeneralTab = ({ user, updateUser }) => {
  return (
    <div className="settings-panel">
      <h3>General</h3>
      <p className="settings-subtitle">Customize your experience</p>
      
      <div className="settings-group">
        <label>Theme</label>
        <div className="theme-options">
          <button className="theme-option" data-theme="light">
            <i className="bx bx-sun"></i>
            <span>Light</span>
          </button>
          <button className="theme-option active" data-theme="dark">
            <i className="bx bx-moon"></i>
            <span>Dark</span>
          </button>
          <button className="theme-option" data-theme="system">
            <i className="bx bx-desktop"></i>
            <span>System</span>
          </button>
        </div>
      </div>
      
      <div className="settings-group">
        <label htmlFor="languageSelect">Language</label>
        <select id="languageSelect" className="settings-select">
          <option value="en">English</option>
          <option value="es">Español</option>
          <option value="fr">Français</option>
          <option value="de">Deutsch</option>
          <option value="ja">日本語</option>
        </select>
      </div>
    </div>
  );
};

export default GeneralTab;