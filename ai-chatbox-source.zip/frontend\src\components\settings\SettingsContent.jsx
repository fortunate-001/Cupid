import { useState } from "react";

import {
  FiSettings,
  FiUser,
  FiShield,
} from "react-icons/fi";

import { HiOutlinePaintBrush } from "react-icons/hi2";
import { LuBrain } from "react-icons/lu";

import GeneralTab from "./tabs/GeneralTab";
import AppearanceTab from "./tabs/AppearanceTab";
import ProfileTab from "./tabs/ProfileTab";
import MemoryTab from "./tabs/MemoryTab";
import AccountTab from "./tabs/AccountTab";

const tabs = [
  {
    name: "General",
    icon: <FiSettings />,
  },
  {
    name: "Appearance",
    icon: <HiOutlinePaintBrush />,
  },
  {
    name: "Profile",
    icon: <FiUser />,
  },
  {
    name: "Memory",
    icon: <LuBrain />,
  },
  {
    name: "Account",
    icon: <FiShield />,
  },
];

export default function SettingsContent() {
  const [activeTab, setActiveTab] =
    useState("General");

  return (
    <div className="settings-layout">

      <aside className="settings-sidebar">

        {tabs.map((tab) => (

          <button
            key={tab.name}
            className={
              activeTab === tab.name
                ? "tab active"
                : "tab"
            }
            onClick={() =>
              setActiveTab(tab.name)
            }
          >

            {tab.icon}

            <span>{tab.name}</span>

          </button>

        ))}

      </aside>

      <section className="settings-content">

        {activeTab === "General" && (
          <GeneralTab />
        )}

        {activeTab === "Appearance" && (
          <AppearanceTab />
        )}

        {activeTab === "Profile" && (
          <ProfileTab />
        )}

        {activeTab === "Memory" && (
          <MemoryTab />
        )}

        {activeTab === "Account" && (
          <AccountTab />
        )}

      </section>

    </div>
  );
}