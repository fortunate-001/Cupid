// src/components/settings/tabs/DataTab.jsx
import React from 'react';

const DataTab = ({ user }) => {
  return (
    <div className="settings-panel">
      <h3>Data</h3>
      <p className="settings-subtitle">Manage your data</p>
      
      <div className="settings-group">
        <button className="danger-btn" style={{ maxWidth: '300px' }}>
          Clear Chat History
        </button>
      </div>
      
      {!user && (
        <div className="settings-group">
          <button className="primary-btn" style={{ maxWidth: '300px' }}>
            Sign Up to Save Your Chats
          </button>
        </div>
      )}
    </div>
  );
};

export default DataTab;