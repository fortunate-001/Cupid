import api from "../api/client";

export const login = async (credentials) => {
  const { data } = await api.post("/auth/login", credentials);

  if (data.token) {
    localStorage.setItem("token", data.token);
  }

  return data;
};

export const register = async (userData) => {
  const { data } = await api.post("/auth/signup", userData);

  if (data.token) {
    localStorage.setItem("token", data.token);
  }

  return data;
};

export const forgotPassword = async (email) => {
  const { data } = await api.post("/auth/forgot-password", {
    email,
  });

  return data;
};

export const resetPassword = async (token, newPassword) => {
  const { data } = await api.post(
    "/auth/reset-password",
    {
      token,
      newPassword,
    }
  );

  return data;
};

export const getCurrentUser = async () => {
  const { data } = await api.get("/auth/me");

  return data;
};

export const logout = () => {
  localStorage.removeItem("token");
};