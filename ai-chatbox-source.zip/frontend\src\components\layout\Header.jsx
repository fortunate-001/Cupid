import { FaRobot, FaUserCircle } from "react-icons/fa";
import { useState } from "react";

import SettingsModal from "../settings/SettingsModal";
import SettingsContent from "../settings/SettingsContent";

export default function Header() {

  const [openSettings, setOpenSettings] =
    useState(false);

  return (

    <>

      <header className="chat-header">

        <div className="logo">

          <FaRobot />

          <h2>Cupid AI</h2>

        </div>

        <FaUserCircle
          className="profile-icon"
          size={30}
          onClick={() => setOpenSettings(true)}
        />

      </header>

      <SettingsModal
        open={openSettings}
        onClose={() => setOpenSettings(false)}
      >

        <SettingsContent />

      </SettingsModal>

    </>

  );

}