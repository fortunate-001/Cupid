// src/components/settings/tabs/ProfileTab.jsx
import React from 'react';

const ProfileTab = ({ user }) => {
  return (
    <div className="settings-panel">
      <h3>Profile</h3>
      <p className="settings-subtitle">Your account information</p>
      
      <div className="profile-avatar-large">
        {user?.name?.charAt(0) || 'U'}
      </div>
      <div className="profile-info">
        <p><strong>Name:</strong> {user?.name || 'User'}</p>
        <p><strong>Email:</strong> {user?.email || 'Not logged in'}</p>
        <p><strong>Plan:</strong> {user?.subscription?.tier || 'Free'}</p>
      </div>
      <button className="primary-btn" style={{ marginTop: '16px', maxWidth: '200px' }}>
        Upgrade Plan
      </button>
    </div>
  );
};

export default ProfileTab;