import { useEffect, useState } from "react";

import {
  FiSettings,
  FiUser,
  FiShield,
} from "react-icons/fi";

import {
  HiOutlinePaintBrush,
} from "react-icons/hi2";

import {
  LuBrain,
  LuVolume2,
  LuVolumeX,
} from "react-icons/lu";

const tabs = [
  {
    name: "General",
    icon: <FiSettings />,
  },

  {
    name: "Appearance",
    icon: <HiOutlinePaintBrush />,
  },

  {
    name: "Profile",
    icon: <FiUser />,
  },

  {
    name: "Memory",
    icon: <LuBrain />,
  },

  {
    name: "Account",
    icon: <FiShield />,
  },
];

export default function SettingsContent() {

  const [activeTab, setActiveTab] =
    useState("General");

  // =========================================
  // VOICE
  // =========================================

  const [voicePreference, setVoicePreference] =
    useState(
      () =>
        localStorage.getItem(
          "cupidVoicePreference"
        ) || "female"
    );


  // =========================================
  // SAVE VOICE
  // =========================================

  const handleVoiceChange =
    (voice) => {

      setVoicePreference(
        voice
      );

      localStorage.setItem(
        "cupidVoicePreference",
        voice
      );

      // Tell MessageBubble
      window.dispatchEvent(
        new CustomEvent(
          "cupidVoiceChanged",
          {
            detail: voice,
          }
        )
      );
    };


  return (
    <div className="settings-layout">

      {/* =====================================
          SIDEBAR
      ===================================== */}

      <aside className="settings-sidebar">

        {tabs.map((tab) => (

          <button
            key={tab.name}
            className={
              activeTab ===
              tab.name
                ? "tab active"
                : "tab"
            }
            onClick={() =>
              setActiveTab(
                tab.name
              )
            }
          >

            {tab.icon}

            <span>
              {tab.name}
            </span>

          </button>

        ))}

      </aside>


      {/* =====================================
          CONTENT
      ===================================== */}

      <section className="settings-content">

        {/* ===================================
            GENERAL
        =================================== */}

        {activeTab ===
          "General" && (

          <div className="settings-section">

            <div className="settings-section-header">

              <h3>
                General
              </h3>

              <p>
                Customize how Cupid
                responds and speaks.
              </p>

            </div>


            {/* ================================
                VOICE
            ================================= */}

            <div className="setting-card">

              <div className="setting-card-info">

                <div className="setting-icon">

                  {voicePreference ===
                  "male" ? (
                    <LuVolume2 />
                  ) : (
                    <LuVolumeX />
                  )}

                </div>

                <div>

                  <h4>
                    Voice
                  </h4>

                  <p>
                    Choose the voice
                    Cupid uses when
                    reading responses
                    aloud.
                  </p>

                </div>

              </div>


              <div className="voice-options">

                {/* FEMALE */}

                <button
                  type="button"
                  className={
                    voicePreference ===
                    "female"
                      ? "voice-option active"
                      : "voice-option"
                  }
                  onClick={() =>
                    handleVoiceChange(
                      "female"
                    )
                  }
                >

                  <div className="voice-option-icon">
                    ♀
                  </div>

                  <div>

                    <strong>
                      Female
                    </strong>

                    <span>
                      Female voice
                    </span>

                  </div>

                </button>


                {/* MALE */}

                <button
                  type="button"
                  className={
                    voicePreference ===
                    "male"
                      ? "voice-option active"
                      : "voice-option"
                  }
                  onClick={() =>
                    handleVoiceChange(
                      "male"
                    )
                  }
                >

                  <div className="voice-option-icon">
                    ♂
                  </div>

                  <div>

                    <strong>
                      Male
                    </strong>

                    <span>
                      Male voice
                    </span>

                  </div>

                </button>

              </div>

            </div>


            {/* ================================
                CURRENT VOICE
            ================================= */}

            <div className="current-setting">

              <span>
                Current voice
              </span>

              <strong>
                {voicePreference ===
                "male"
                  ? "Male"
                  : "Female"}
              </strong>

            </div>

          </div>
        )}


        {/* ===================================
            APPEARANCE
        =================================== */}

        {activeTab ===
          "Appearance" && (

          <div className="settings-section">

            <div className="settings-section-header">

              <h3>
                Appearance
              </h3>

              <p>
                Customize the appearance
                of Cupid.
              </p>

            </div>

            <div className="setting-card">

              <h4>
                Appearance settings
              </h4>

              <p>
                Your appearance
                controls will go here.
              </p>

            </div>

          </div>
        )}


        {/* ===================================
            PROFILE
        =================================== */}

        {activeTab ===
          "Profile" && (

          <div className="settings-section">

            <div className="settings-section-header">

              <h3>
                Profile
              </h3>

              <p>
                Manage your Cupid
                profile.
              </p>

            </div>

            <div className="setting-card">

              <h4>
                Profile settings
              </h4>

              <p>
                Your profile controls
                will go here.
              </p>

            </div>

          </div>
        )}


        {/* ===================================
            MEMORY
        =================================== */}

        {activeTab ===
          "Memory" && (

          <div className="settings-section">

            <div className="settings-section-header">

              <h3>
                Memory
              </h3>

              <p>
                Control how Cupid
                remembers your
                conversations.
              </p>

            </div>

            <div className="setting-card">

              <h4>
                Memory settings
              </h4>

              <p>
                Your memory controls
                will go here.
              </p>

            </div>

          </div>
        )}


        {/* ===================================
            ACCOUNT
        =================================== */}

        {activeTab ===
          "Account" && (

          <div className="settings-section">

            <div className="settings-section-header">

              <h3>
                Account
              </h3>

              <p>
                Manage your account
                settings.
              </p>

            </div>

            <div className="setting-card">

              <h4>
                Account settings
              </h4>

              <p>
                Your account controls
                will go here.
              </p>

            </div>

          </div>
        )}

      </section>

    </div>
  );
}