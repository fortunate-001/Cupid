export default function AppearanceTab(){

    return(

        <>

            <h2>

                Appearance

            </h2>

            <p>

                Customize how Cupid looks.

            </p>

        </>

    );

}