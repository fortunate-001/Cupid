import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useFormik } from "formik";
import * as Yup from "yup";
import { FaEye, FaEyeSlash, FaRobot } from "react-icons/fa";
import { toast } from "react-hot-toast";
import { useAuth } from "../context/AuthContext";
import "../styles/auth.css";

function Login() {
  const { login } = useAuth();

  const navigate = useNavigate();

  const [showPassword, setShowPassword] = useState(false);

  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },

    validationSchema: Yup.object({
      email: Yup.string()
        .email("Invalid email")
        .required("Email is required"),

      password: Yup.string()
        .required("Password is required")
        .min(6, "Minimum 6 characters"),
    }),

    onSubmit: async (values, { setSubmitting }) => {
        try {

            await login(values);

            sessionStorage.removeItem("guest_mode");

            toast.success("Welcome back!");

            navigate("/chat", {
            replace: true,
            });

        } catch (err) {

            toast.error(
            err.response?.data?.error ||
            "Login failed"
            );

        } finally {

            setSubmitting(false);

        }
        },
  });

  return (
    <div className="login-page">
        <div className="login-card">

            <div className="login-logo">
            <FaRobot />
            </div>

            <h1>Welcome Back</h1>

            <p>Sign in to Cupid AI</p>

            <form onSubmit={formik.handleSubmit}>

                <div className="input-group">

                    <label>Email</label>

                    <input name="email" type="email"
                    placeholder="Email" value={formik.values.email} onChange={formik.handleChange}
                    onBlur={formik.handleBlur}
                    />

                    {formik.touched.email &&
                    formik.errors.email && (
                        <small className="error">{formik.errors.email}</small>
                    )}

                </div>

                <div className="input-group">

                    <label>Password</label>

                    <div className="password-box">

                        <input
                            name="password"
                            type={
                            showPassword
                                ? "text"
                                : "password"
                            }
                            placeholder="Password"
                            value={formik.values.password}
                            onChange={formik.handleChange}
                            onBlur={formik.handleBlur}
                        />

                        <button
                            type="button"
                            onClick={() =>
                            setShowPassword(!showPassword)
                            }
                        >
                            {showPassword ? (
                            <FaEyeSlash />
                            ) : (
                            <FaEye />
                            )}
                        </button>

                    </div>

                    {formik.touched.password &&
                    formik.errors.password && (
                        <small className="error">
                        {formik.errors.password}
                        </small>
                    )}

                </div>

                <Link
                    to="/forgot-password"
                    className="forgot-link"
                >
                    Forgot Password?
                </Link>

                <button
                    type="submit"
                    className="login-btn"
                    disabled={formik.isSubmitting}
                >
                    {formik.isSubmitting
                    ? "Signing In..."
                    : "Login"}
                </button>

            </form>

            <p className="bottom-text">
            Don't have an account?

            <Link to="/register">
                Register
            </Link>

            </p>

        </div>
    </div>
  );
}

export default Login;